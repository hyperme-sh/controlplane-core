"""Shared tenancy interfaces."""
